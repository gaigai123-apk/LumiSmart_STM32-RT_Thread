#include <rtthread.h>
#include <rtdevice.h>
#include <drv_common.h>

/* 低电平有源蜂鸣器，默认 PB12 */
#ifndef BUZZER_PIN
#define BUZZER_PIN   GET_PIN(B, 12)
#endif

void Buzzer_Init(void)
{
	rt_pin_mode(BUZZER_PIN, PIN_MODE_OUTPUT);
	/* 默认关闭（高电平） */
	rt_pin_write(BUZZER_PIN, PIN_HIGH);
}

void Buzzer_ON(void)
{
	rt_pin_write(BUZZER_PIN, PIN_LOW);
}

void Buzzer_OFF(void)
{
	rt_pin_write(BUZZER_PIN, PIN_HIGH);
}

void Buzzer_Turn(void)
{
	int v = rt_pin_read(BUZZER_PIN);
	rt_pin_write(BUZZER_PIN, v ? PIN_LOW : PIN_HIGH);
}
