#include <rtthread.h>
#include <rtdevice.h>
#include <drv_common.h>

/* 数字型光敏开关输入，默认 PB13 上拉 */
#ifndef LIGHT_SENSOR_PIN
#define LIGHT_SENSOR_PIN   GET_PIN(B, 13)
#endif

void LightSensor_Init(void)
{
	rt_pin_mode(LIGHT_SENSOR_PIN, PIN_MODE_INPUT_PULLUP);
}

uint8_t LightSensor_Get(void)
{
	return (uint8_t)rt_pin_read(LIGHT_SENSOR_PIN);
}
