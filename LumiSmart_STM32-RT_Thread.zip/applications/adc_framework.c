/* 临时引入 RT-Thread ADC 框架源码，确保链接符号可用。
 * 若后续在 RT-Thread Studio 设置里启用了 ADC 并自动编译该模块，
 * 出现重复定义时删除本文件即可。*/

#include "../rt-thread/components/drivers/misc/adc.c"


